---
title: 关于hexo的使用指南（一）
date: 2023-03-27 20:40:28
tags: hexo
---
# 什么是hexo
关于hexo，本篇文章就不多赘述，主要了解它是静态网站和使用Markdown渲染即可
具体关于hexo你可以百度查询或登录[hexo官网](https://hexo.io)了解
# 搭建安装环境
hexo主要以**Git**和**node.js**两个软件作为依赖项
Git:[Git官网](https://git-scm.com)
Node.js:[Node.js官网](https://nodejs.org/zh-cn)
版本最好是长期维护版本，~当然，beta版也无所谓~
安装包直接无脑okokok（可以改储存盘）

检测node.js是否安装，可以在cmd输入
``` cmd
node -v     
```

``` bash
pnpm add hexo-cli -g
hexo init --no-install
pnpm i
```

如果输出版本号即为安装成功  
![114514](https://i.hd-r.cn/76a560dd4dd48da5de4efbd47fc7eab3.png)
检测Git是否安装，可以在桌面右键
如果选项中出现 “Git Bash Here”和“Git GUI Here"(下文我以GBH称呼)即为安装成功

# 安装hexo
你可以在任何盘符里安装hexo，但最好在C盘以外
新建一个文件夹命名为hexo
打开我们创建的文件夹，单击右键选择“GBH”，输入一下代码

>    
     npm install hexo-cli -g
     hexo init blog
     cd blog
     npm install  //下载模块


如果没有任何问题，我们应在blog文件夹中看到以下文件
![你太聪明了](https://i.hd-r.cn/8c4fabe530f2f753292a87e811a5d926.png)